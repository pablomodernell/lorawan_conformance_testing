devices_to_configure = {'70B3D52C70104BE2': {'appeui': '70B3D52C70100137', 'id': 19426,
                                             'appkey': '75E3205B17A819F9724B22EE2CA36CF1',
                                             'command': '940070B3D52C70104BE2AAB3D52C7010013705A0000106C0'}}