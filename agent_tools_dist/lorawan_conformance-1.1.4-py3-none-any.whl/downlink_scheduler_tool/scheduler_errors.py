class DuplicatedNonce(Exception):
    pass

